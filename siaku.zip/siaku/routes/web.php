<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\latihan;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/greeting', function () {
    return 'Hello World';
});

Route::get('/lev', function () {
    return 'levy gunawan';
});

Route::get('/biodata', function () {
    return view('latihan', ['name' => 'Levy','kelas' => 'IK19B', 'hobby' => 'Push Rank', 'umur' => '20']);
});

Route::get('/test', [latihan::class, 'biodata']);
Route::get('/dashboard', [HomeController::class, 'index']);
