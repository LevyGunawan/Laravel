<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;

class latihan extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function biodata()
    {

        $data['status'] = array('warganegara' => 'Indonesia',
        'agama' => 'Islam',
        'instansi' => 'PT Anjim Kaya',
        'posisi' => 'Manager');
        
        $data['biodata'] = array('nama' => 'Levy',
        'kelas' => 'IK19B',
        'hobby' => 'Push Rank',
        'umur' => '20');

        $data['pengalaman'] = array(
        'seminar' => 'LCC',
        'tempat' => 'LP3I',
        'narasumber' => 'Cyber Crime',
        'waktu' => 'Tahun lalu',
        );


        return view('latihan', $data);
    }
}