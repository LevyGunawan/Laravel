<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use App\Models\User_menu;
  
class HomeController extends Controller
{
    public function index()
    {
        $posts = User_menu::get();
         
        /// mengirimkan variabel $posts ke halaman views posts/index.blade.php
        /// include dengan number index
        return view('dashboard',compact('posts'));
    }
} 