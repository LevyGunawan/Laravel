<?php
namespace App\Helper;

use Illuminate\Support\Facades\DB;

class general_helper {
    public static function getMenu() {
        $builder = $db->table('user_menus');
        $GLOBALS['user_group_id'] = 1;


        $getMenu = DB::table('user_menus')
        ->select('user_menus.id', 'user_menus.parent_id', 'user_menus.url
        ','user_menus.icon_menu')
        ->leftjoin('user_rules', 'user_menus.id', '=' , 'user_rules.menu_id')
        ->where('user_rules.group_id',$GLOBALS['user_group_id'])
        ->where('user_menus.show_in_menu',1)
        ->get();

        return general_helper::sortMenu($getMenu);
    }

    public static function sortMenu($raw, $parent_id = 0){

        $return = array();

        foreach($raw as $key)
        {
            $proceed = FALSE;
            if ($key->parent_id == $parent_id)
            {
                $return = $key;
                $proceed = TRUE;
            }
            if($proceed) $return->child = general_helper::sortMenu($raw, $key->id);
        }
        return $return;
    }
}