<html>
    <body>
        <h1>Hello, Saya adalah <?php echo e($biodata['nama']); ?> 
        kelas <?php echo e($biodata['kelas']); ?> 
        saya mempunyai sebuah hobby yaitu <?php echo e($biodata['hobby']); ?>

        dan saya sekarang berumur <?php echo e($biodata ['umur']); ?></h1>

        <h1>saya sebagai <?php echo e($status ['posisi']); ?> 
        di <?php echo e($status ['instansi']); ?>

        sebagai warga negara <?php echo e($status ['warganegara']); ?>

        dan beragama  <?php echo e($status ['agama']); ?></h1>

        <h1>Saya pernah mengikuti sebuah seminar <?php echo e($pengalaman ['seminar']); ?>

        yang bertempat di <?php echo e($pengalaman ['tempat']); ?>

        dan dibawakan oleh <?php echo e($pengalaman ['narasumber']); ?>

        yang diadakan pada <?php echo e($pengalaman ['waktu']); ?>

        </h1>
    </body>
</html><?php /**PATH C:\xampp\htdocs\siaku\resources\views/latihan.blade.php ENDPATH**/ ?>