<html>
    <body>
        <h1>Hello, Saya adalah {{$biodata['nama'] }} 
        kelas {{$biodata['kelas'] }} 
        saya mempunyai sebuah hobby yaitu {{ $biodata['hobby'] }}
        dan saya sekarang berumur {{ $biodata ['umur'] }}</h1>

        <h1>saya sebagai {{$status ['posisi'] }} 
        di {{$status ['instansi'] }}
        sebagai warga negara {{$status ['warganegara'] }}
        dan beragama  {{$status ['agama'] }}</h1>

        <h1>Saya pernah mengikuti sebuah seminar {{$pengalaman ['seminar'] }}
        yang bertempat di {{$pengalaman ['tempat'] }}
        dan dibawakan oleh {{$pengalaman ['narasumber'] }}
        yang diadakan pada {{$pengalaman ['waktu'] }}
        </h1>
    </body>
</html>